// Normalizar datos de noticias antes de guardarlos
function normalizeNewsPayload(body) {
  const { title, content, author, date, category } = body;
  if (!title || !content) throw new Error('Los campos "title" y "content" son obligatorios');
  
  const payload = {
    title: String(title).trim(),
    content: String(content).trim(),
    author: author ? String(author).trim() : null,
    date: parseDateField(date, 'date') || new Date(),
    category: category ? String(category).trim() : null,
  };
  
  return payload;
}

// ============= NEWS ENDPOINTS =============

//GET: Para listar todas las noticias
app.get('/api/news', async (req, res) => {
  try {
    const news = await db.collection('noticias')
      .find({})
      .sort({ date: -1 })
      .toArray();
    res.json(news);
  } catch (err) {
    console.error('Error en GET /api/news:', err);
    res.status(500).json({ error: 'Error al obtener noticias' });
  }
});

//POST: Crear noticia + subir imágenes en AZURE
app.post('/api/news', upload.array('files', 10), async (req, res) => {
  try {
    const newsItem = normalizeNewsPayload(req.body);
    if (!newsItem.title || !newsItem.content) {
      return res.status(400).json({ error: 'Los campos "title" y "content" son obligatorios' });
    }

    // 1) Inserta sin fotos para obtener _id
    const baseDoc = { ...newsItem, photos: [] };
    const result = await db.collection('noticias').insertOne(baseDoc);
    const _id = result.insertedId;

    // 2) Sube imágenes bajo carpeta del _id
    const files = Array.isArray(req.files) ? req.files : [];
    const photos = [];
    for (const f of files) {
      const ext = extFromMime(f.mimetype);
      const blobName = `news/${_id}/${randomName(ext)}`;
      const block = container.getBlockBlobClient(blobName);
      await block.uploadData(f.buffer, { blobHTTPHeaders: { blobContentType: f.mimetype } });
      photos.push({ blobName, mime: f.mimetype, size: f.size, uploadedAt: new Date() });
    }

    // 3) Actualiza el doc con las fotos
    if (photos.length) {
      await db.collection('noticias').updateOne({ _id }, { $push: { photos: { $each: photos } } });
    }

    // 4) Devuelve el doc final
    const doc = await db.collection('noticias').findOne({ _id });
    res.status(201).json(doc);
  } catch (err) {
    console.error('POST /api/news error:', err);
    res.status(400).json({ error: err.message || 'Error al crear noticia' });
  }
});

// DELETE: Eliminar noticia de la BBDD
app.delete('/api/news/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });

    const result = await db.collection('noticias').deleteOne({ _id: new ObjectId(id) });
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'Noticia no encontrada' });
    }
    res.json({ ok: true });
  } catch (err) {
    console.error('Error en DELETE /api/news/:id:', err);
    res.status(500).json({ error: 'Error al eliminar noticia' });
  }
});

//PUT: Actualizar noticia
app.put('/api/news/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const filter = buildIdFilter(id);
    const payload = normalizeNewsPayload(req.body);

    console.log('[PUT NEWS] id:', id);
    console.log('[PUT NEWS] filter:', JSON.stringify(filter));

    const r = await db.collection('noticias').updateOne(filter, { $set: payload });

    console.log('[PUT NEWS] matched:', r.matchedCount, 'modified:', r.modifiedCount);

    if (r.matchedCount === 0) {
      return res.status(404).json({ error: 'Noticia no encontrada' });
    }

    const updated = await db.collection('noticias').findOne(filter);
    console.log('[PUT NEWS] returning _id:', updated?._id);
    return res.json(updated);
  } catch (err) {
    console.error('Error en PUT /api/news/:id', err);
    return res.status(400).json({ error: err.message || 'Error al actualizar noticia' });
  }
});

// GET: Devuelve fotos de una noticia
app.get('/api/news/:id/photos', async (req, res) => {
  try {
    const { id } = req.params;
    const newsItem = await db.collection('noticias').findOne(buildIdFilter(id), { projection: { photos: 1 } });
    if (!newsItem) return res.status(404).json({ error: 'Noticia no encontrada' });
    const out = (newsItem.photos || []).map(p => ({ ...p, url: blobUrlWithSas(p.blobName) }));
    res.json(out);
  } catch (e) {
    res.status(400).json({ error: e.message || 'Error al obtener fotos' });
  }
});
