//CONFIG
const API_BASE = 'http://127.0.0.1:4000/api'; //Backend de forma local
//const API_BASE = 'https://esdibdemo.azurewebsites.net/api'; //Backend para azure

const API_KEY = '893162e86356d5e5abf0a2fd3aac051129d2bd36281b890410c04f207f68998e'; //API KEY del backend

// Estado
let editingId = null; //Para el sistema de edicion

// Auth State
function getAuthHeaders() {
  const token = localStorage.getItem('auth_token');
  return token ? { 'Authorization': `Basic ${token}` } : {};
}
function getCurrentUser() {
  const u = localStorage.getItem('current_user');
  return u ? JSON.parse(u) : null;
}
function logout() {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('current_user');
  window.location.reload();
}

//Funciones helpers
const q = (id) => document.getElementById(id);
const val = (id) => (q(id)?.value ?? '').trim();
function toNullIfEmpty(s) { if (s == null) return null; const t = String(s).trim(); return t === '' ? null : t; }

//Funcion para adaptar el _id de mongo a string
function normId(p) {
  if (!p || !p._id) return null;
  if (typeof p._id === 'string') return p._id;
  if (typeof p._id === 'object' && p._id.$oid) return p._id.$oid;
  try { return String(p._id); } catch { return null; }
}

//Función para errores y cabeceras
async function apiFetch(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    'x-api-key': API_KEY,
    ...getAuthHeaders(),
    ...(options.headers || {})
  };

  // Si body es FormData, quitamos Content-Type para que el navegador ponga el correcto multipart
  if (options.body instanceof FormData) {
    delete headers['Content-Type'];
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers
  });

  if (res.status === 401 || res.status === 403) {
    const msg = await res.json().catch(() => ({ error: 'No autorizado' }));
    throw new Error(msg.error || 'No tienes permiso para esta acción');
  }

  if (!res.ok) {
    const msg = await res.text().catch(() => 'Error');
    // Try to parse json error first
    try {
      const json = JSON.parse(msg);
      throw new Error(json.error || msg);
    } catch {
      throw new Error(msg || 'Error de red');
    }
  }
  return res.status !== 204 ? res.json() : null;
}

//Funcion para añadir todas las imagenes de azure en el front
async function renderPhotosForNews(newsItem, photosWrap) {
  photosWrap.innerHTML = ''; // limpia

  // 1) Si ya vienen URLs en el documento (p.ej. backend añade SAS)
  const hasInlineUrls = Array.isArray(newsItem.photos) && newsItem.photos.some(ph => ph && ph.url);
  if (hasInlineUrls) {
    newsItem.photos.forEach(ph => {
      if (!ph?.url) return;
      const img = document.createElement('img');
      img.src = ph.url;
      img.alt = newsItem.title || 'foto';
      photosWrap.appendChild(img);
    });
    if (photosWrap.children.length === 0) {
      photosWrap.innerHTML = '<span class="muted">(sin imágenes)</span>';
    }
    return;
  }

  // 2) Si no vienen URLs pero sí blobNames, intenta pedir al backend /photos (con SAS)
  const id = normId(newsItem);
  if (id) {
    try {
      const arr = await apiFetch(`/news/${id}/photos`, { method: 'GET' });
      if (Array.isArray(arr) && arr.length > 0) {
        arr.forEach(ph => {
          if (!ph?.url) return;
          const img = document.createElement('img');
          img.src = ph.url;
          img.alt = newsItem.title || 'foto';
          photosWrap.appendChild(img);
        });
        if (photosWrap.children.length > 0) return;
      }
    } catch (e) {
      console.warn('No se pudieron obtener URLs SAS para', id, e);
    }
  }

  // 3) Fallback si no hay nada que mostrar
  photosWrap.innerHTML = '<span class="muted"></span>';
}

// Check permissions
function canEdit(n) {
  const user = getCurrentUser();
  if (!user) return false;
  if (user.role === 'admin') return true;
  return n.authorId === user._id || (n.author === user.username); // Fallback to name match if id logic fails, but ID is safer
}

//Función para obtener todo el contenido de la BBDD y crear un listado
async function cargarLista() {
  try {
    const data = await apiFetch('/news', { method: 'GET' });
    const newsList = Array.isArray(data) ? data : (Array.isArray(data?.items) ? data.items : []);
    const list = q('pets-list');
    if (!list) return;
    list.innerHTML = '';

    for (const n of newsList) {
      const li = document.createElement('li');
      li.className = 'pet-item';

      const header = document.createElement('div');
      header.className = 'pet-header';
      const title = n?.title || '(sin título)';
      const category = n?.category ? ` [${n.category}]` : '';
      header.textContent = `${title}${category}`;

      // Meta info
      const meta = document.createElement('div');
      meta.className = 'news-meta';
      const author = n?.author ? `Por: ${n.author}` : '';
      const date = n?.date ? new Date(n.date).toLocaleDateString('es-ES') : '';
      meta.textContent = `${author}${author && date ? ' | ' : ''}${date}`;

      // Content preview
      const content = document.createElement('div');
      content.className = 'news-content';
      const contentText = n?.content || '';
      content.textContent = contentText.length > 150 ? contentText.substring(0, 150) + '...' : contentText;

      // Acciones (Solo si tiene permiso)
      const actions = document.createElement('div');
      actions.className = 'pet-actions';

      if (canEdit(n)) {
        const edit = document.createElement('button');
        edit.textContent = 'Editar';
        edit.onclick = () => startEdit(n);

        const del = document.createElement('button');
        del.textContent = 'Eliminar';
        del.onclick = async () => {
          const id = normId(n);
          if (!id) return alert('ID no válido');
          if (!confirm('¿Eliminar esta noticia?')) return;
          try {
            await apiFetch(`/news/${id}`, { method: 'DELETE' });
            await cargarLista();
            if (editingId === id) resetForm();
          } catch (e) {
            alert('Error al eliminar: ' + e.message);
          }
        };

        actions.appendChild(edit);
        actions.appendChild(del);
      }

      const photosWrap = document.createElement('div');
      photosWrap.className = 'pet-photos';
      await renderPhotosForNews(n, photosWrap);

      li.appendChild(header);
      li.appendChild(meta);
      li.appendChild(content);
      if (actions.hasChildNodes()) li.appendChild(actions);
      li.appendChild(photosWrap);
      list.appendChild(li);
    }
  } catch (e) {
    console.error(e);
    // Ignore errors for unauth users on load if desired, or show alert
    // alert('Error al cargar la lista de noticias');
  }
}

// Construir el payload JSON para UPDATE (sin fotos)
function buildJsonPayloadFromForm() {
  return {
    title: val('title'),
    content: val('content'),
    // author: val('author') || null, // Author is handled by backend token now
    date: val('date') || null,
    category: q('category').value || null,
  };
}


//Función que envia los datos del formulario y las fotos al backend
async function onSubmitForm(ev) {
  ev.preventDefault();

  if (!getCurrentUser()) {
    alert('Debes iniciar sesión para publicar');
    window.location.href = 'login.html';
    return;
  }

  const btn = q('upload-button');
  btn.disabled = true;

  try {
    if (!val('title') || !val('content')) {
      alert('Los campos "Título" y "Contenido" son obligatorios');
      return;
    }

    // MODO EDICIÓN: hacemos PUT /news/:id con JSON (sin fotos)
    if (editingId) {
      const payload = buildJsonPayloadFromForm();
      await apiFetch(`/news/${editingId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      alert('Noticia actualizada');
      await cargarLista();
      resetForm();
      return;
    }

    // MODO CREACIÓN: hacemos POST /news con FormData (datos + fotos)
    const fd = new FormData();
    fd.append('title', val('title'));
    fd.append('content', val('content'));
    // fd.append('author', val('author')); // Backend uses logged in user
    fd.append('date', q('date').value);
    fd.append('category', q('category').value);

    const fileInput = q('files');
    if (fileInput.files && fileInput.files.length > 0) {
      for (const f of fileInput.files) {
        fd.append('files', f, f.name);
      }
    }

    // apiFetch handles Auth headers
    await apiFetch('/news', {
      method: 'POST',
      body: fd
    });

    alert('Noticia publicada exitosamente');
    await cargarLista();
    resetForm();
  } catch (e) {
    console.error(e);
    alert('Error al guardar: ' + e.message);
  } finally {
    btn.disabled = false;
  }
}


//Función para resetear el formulario
function resetForm() {
  q('alta_pet')?.reset();
  editingId = null;
  const label = document.querySelector('#upload-button label');
  if (label) label.textContent = 'PUBLICAR';
  q('cancel-edit').style.display = 'none';
  const title = document.querySelector('.title');
  if (title) title.textContent = 'PUBLICAR NOTICIA DE ECOLOGÍA';
}

// Esto es para rellenar todo el formulario con los datos del registro a editar
function startEdit(n) {
  const id = normId(n);
  if (!id) return alert('ID no válido');
  editingId = id;

  q('title').value = n.title || '';
  q('content').value = n.content || '';
  q('author').value = n.author || '';
  q('category').value = n.category || '';

  if (n.date) {
    const d = new Date(n.date);
    q('date').value = isNaN(d.getTime()) ? '' :
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  } else {
    q('date').value = '';
  }

  const label = document.querySelector('#upload-button label');
  if (label) label.textContent = 'ACTUALIZAR';
  q('cancel-edit').style.display = 'inline-block';
  const title = document.querySelector('.title');
  if (title) title.textContent = 'EDITAR NOTICIA';

  q('title').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateUIForUser() {
  const user = getCurrentUser();
  const navLogin = q('nav-login-btn');
  if (navLogin) {
    if (user) {
      navLogin.textContent = `Hola, ${user.username} (Salir)`;
      navLogin.href = "#";
      navLogin.onclick = (e) => {
        e.preventDefault();
        logout();
      };
    } else {
      navLogin.textContent = 'Login';
      navLogin.href = 'login.html';
      navLogin.onclick = null;
    }
  }

  // Hide or disable form if not logged in?
  // Maybe just show a message.
  const form = q('alta_pet');
  if (form && !user) {
    // Optional: could hide form or show login prompt
    // For now we rely on submit alert
  }
}

//Arranqueee!!!
document.addEventListener('DOMContentLoaded', () => {
  updateUIForUser();
  cargarLista();
  q('alta_pet')?.addEventListener('submit', onSubmitForm);
  q('cancel-edit')?.addEventListener('click', resetForm);

  // Mobile Menu Logic
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  const overlay = document.querySelector('.overlay');

  function toggleMenu() {
    nav.classList.toggle('active');
    overlay.classList.toggle('active');
    // Change hamburger icon to X or similar animation if CSS supports it
  }

  if (menuToggle) {
    menuToggle.addEventListener('click', toggleMenu);
  }

  if (overlay) {
    overlay.addEventListener('click', toggleMenu);
  }
});