import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { MongoClient, ObjectId } from 'mongodb';
import { BlobServiceClient } from '@azure/storage-blob';


// Cargar variables de entorno desde .env
dotenv.config();

//Configuraciones de entorno
const { MONGODB_URI, MONGODB_DB, port = process.env.PORT || 4000, API_KEY, AZURE_STORAGE_CONNECTION_STRING, AZURE_BLOB_CONTAINER, AZURE_STORAGE_ACCOUNT, AZURE_SAS_TOKEN } = process.env;

// Verificar si falta algo crítico
if (!MONGODB_URI || !MONGODB_DB || !API_KEY || !AZURE_STORAGE_CONNECTION_STRING || !AZURE_BLOB_CONTAINER || !AZURE_STORAGE_ACCOUNT || !AZURE_SAS_TOKEN) {
  console.error('Faltan variables de entorno: MONGODB_URI, MONGODB_DB, API_KEY, AZURE...');
  process.exit(1);
} 

// Cliente de Azure Blob
const blobService = new BlobServiceClient(
  `https://${AZURE_STORAGE_ACCOUNT}.blob.core.windows.net?${AZURE_SAS_TOKEN}`
);

const container = blobService.getContainerClient(AZURE_BLOB_CONTAINER);

const app = express();

// Helper: genera URL pública con SAS incluido
function blobUrlWithSas(blobName) {
  return `https://${AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/${AZURE_BLOB_CONTAINER}/${blobName}?${AZURE_SAS_TOKEN}`;
}

// Middlewares de seguridad y utilidades
//Para trabajar de forma local:
//app.use(helmet());

//Para poder trabajar con la pagina subida a azure:
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "connect-src": ["'self'", "http://127.0.0.1:4000", "ws://127.0.0.1:4000"], // llamadas fetch/XHR al mismo origen
      "img-src": ["'self'", "https:", "data:", "https://esdibstorage.blob.core.windows.net"],
    }
  }
}));
app.use(cors({ origin: true, credentials: true })); // Habilitar CORS
app.use(express.json()); // Parsear JSON
app.use(morgan('dev')); // Logs HTTP
import multer from 'multer';
import crypto from 'crypto';

// Para que se vea desde azure y no de problemas de autenticidad
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, 'public')));


// Configurar Multer para la subida de imágenes
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 10 }, // 8MB por archivo, máx 10 archivos
  fileFilter: (req, file, cb) => {
    const ok = /image\/(png|jpe?g|webp)/i.test(file.mimetype);
    cb(ok ? null : new Error('Solo imágenes (png/jpg/webp)'), ok);
  }
});

// Generador de nombres y extensiones para imagenes
const randomName = (ext='bin') => crypto.randomBytes(16).toString('hex') + '.' + ext;
const extFromMime = m => (m?.split('/')[1] || 'bin').replace('jpeg','jpg');

// Auth por API Key
const apiKeyGuard = (req, res, next) => {
  if (req.header('x-api-key') !== process.env.API_KEY) return res.status(401).json({ error: 'No autorizado' });
  next();
};
app.use('/api', apiKeyGuard);

// Conexión a MONGODB
let client;
let db;
async function connectToMongo() {
  client = new MongoClient(MONGODB_URI);
  await client.connect();
  db = client.db(MONGODB_DB);
  console.log('✅ Conectado a MongoDB');
}


//Helpers de validación
function parseIntegerField(value, fieldName) {
  if (value === undefined || value === null || value === '') return null;
  const num = Number.parseInt(value, 10);
  if (Number.isNaN(num)) {
    throw new Error(`El campo "${fieldName}" debe ser un número entero`);
  }
  return num;
}
function parseDateField(value, fieldName) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) {
    throw new Error(`El campo "${fieldName}" no es una fecha válida`);
  }
  return d;
}

//Normalizar todos los datos que se suben antes de guardarlos.
function normalizePetPayload(body) {
  const { animal, nombre, raza, collar, edad, pelo, tamaño, color, sexo, fecha, descripcion } = body;
  if (!animal || !nombre) throw new Error('Los campos "animal" y "nombre" son obligatorios');
    const payload = {
    animal: String(animal).trim(),
    nombre: String(nombre).trim(),
    raza: raza ? String(raza).trim() : null,
    collar: parseIntegerField(collar, 'collar'),
    edad: parseIntegerField(edad, 'edad'),
    pelo: pelo ? String(pelo).trim() : null,
    color: color ? String(color).trim() : null,
    sexo: sexo ? String(sexo).trim() : null,
    fecha: parseDateField(fecha, 'fecha'),
    descripcion: descripcion ? String(descripcion).trim() : null,
  };
    payload['tamaño'] = tamaño ? String(tamaño).trim() : null;
    return payload;
  }
